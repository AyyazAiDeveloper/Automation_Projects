"use client";

import { GitHubIcon } from "@/components/icons/github-icon";
import { Button } from "@/components/ui/button";
import { formatAbbreviatedNumber } from "@/lib/utils/format-number";
import { useGitHubStars } from "./github-stars-provider";

const GITHUB_REPO_URL =
  "https://github.com/vercel-labs/workflow-builder-template";

export function GitHubStarsButton() {
  const stars = useGitHubStars();

  return (
    <Button
      asChild
      className="h-9 gap-1.5 px-2 sm:px-3"
      size="sm"
      variant="ghost"
    >
      <a
        className="flex items-center"
        href={GITHUB_REPO_URL}
        rel="noopener noreferrer"
        target="_blank"
      >
        <GitHubIcon className="size-4.5" />
        {stars !== null && (
          <span className="hidden text-sm sm:inline">
            {formatAbbreviatedNumber(stars)} stars
          </span>
        )}
      </a>
    </Button>
  );
}
